# Codex Workspace

Portable multi-language development workspace designed for coding agents.

## Included
- Node.js / npm
- Python / virtualenv
- Go
- Rust
- C/C++ toolchain
- Java
- Docker / Dev Container
- GitHub Actions CI
- ShellCheck
- ripgrep / fd / jq / zip / unzip
- Automated setup, test, lint, typecheck and build detection

## Quick start

```bash
bash .codex/setup.sh
bash scripts/check.sh
```

Or:

```bash
make setup
make check
```

See `docs/` for development and testing conventions.
