#!/usr/bin/env bash
set -euo pipefail
bash .codex/setup.sh
