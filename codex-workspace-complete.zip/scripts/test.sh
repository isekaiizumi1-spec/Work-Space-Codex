#!/usr/bin/env bash
set -Eeuo pipefail
if [[ -f package.json ]]; then npm test --if-present; fi
if [[ -f pyproject.toml || -f requirements.txt ]]; then
  PY=".venv/bin/python"; [[ -x "$PY" ]] || PY="python3"
  "$PY" -m pytest -q 2>/dev/null || true
fi
if [[ -f go.mod ]]; then go test ./...; fi
if [[ -f Cargo.toml ]]; then cargo test; fi
