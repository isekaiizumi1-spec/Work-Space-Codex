#!/usr/bin/env bash
set -Eeuo pipefail
if [[ -f package.json ]]; then npm run lint --if-present; npm run typecheck --if-present; fi
if [[ -f pyproject.toml || -f requirements.txt ]]; then
  PY=".venv/bin/python"; [[ -x "$PY" ]] || PY="python3"
  "$PY" -m compileall -q . || true
fi
if [[ -f go.mod ]]; then go vet ./...; fi
if [[ -f Cargo.toml ]]; then cargo clippy --all-targets --all-features -- -D warnings; fi
command -v shellcheck >/dev/null && find scripts -type f -name '*.sh' -print0 | xargs -0 -r shellcheck || true
