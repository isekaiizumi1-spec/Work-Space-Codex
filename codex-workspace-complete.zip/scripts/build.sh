#!/usr/bin/env bash
set -Eeuo pipefail
if [[ -f package.json ]]; then npm run build --if-present; fi
if [[ -f go.mod ]]; then go build ./...; fi
if [[ -f Cargo.toml ]]; then cargo build; fi
