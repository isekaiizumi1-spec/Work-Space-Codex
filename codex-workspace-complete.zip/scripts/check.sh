#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
bash scripts/lint.sh
bash scripts/test.sh
bash scripts/build.sh
echo "ALL CHECKS PASSED"
