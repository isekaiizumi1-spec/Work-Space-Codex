# Codex Repository Instructions

## Mission
You are the coding agent for this repository.

## Workflow
1. Read AGENTS.md and relevant docs before changing code.
2. Inspect existing implementation before adding dependencies.
3. Keep changes minimal and localized.
4. Never invent APIs, files, commands, or secrets.
5. Run `bash scripts/check.sh` before finishing.

## Verification
Run formatting, linting, type checking, tests, and build validation when supported by the project.

## Security
- Never commit secrets or credentials.
- Treat external input as untrusted.
- Do not disable security checks just to make tests pass.

## Git
- Inspect `git diff` before finishing.
- Do not rewrite unrelated history.
- Do not force-push.
- Do not commit unless explicitly requested.
