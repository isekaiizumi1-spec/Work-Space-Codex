#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
command -v git >/dev/null || { echo "git is required" >&2; exit 1; }

if [[ -f package.json ]]; then
  if [[ -f pnpm-lock.yaml ]] && command -v pnpm >/dev/null; then pnpm install --frozen-lockfile
  elif [[ -f yarn.lock ]] && command -v yarn >/dev/null; then yarn install --frozen-lockfile
  elif command -v npm >/dev/null; then npm ci 2>/dev/null || npm install
  else echo "No Node package manager found" >&2; exit 1; fi
fi

if [[ -f pyproject.toml || -f requirements.txt ]]; then
  command -v python3 >/dev/null || { echo "Python 3 is required" >&2; exit 1; }
  python3 -m venv .venv 2>/dev/null || true
  PY=".venv/bin/python"
  [[ -x "$PY" ]] || PY="python3"
  "$PY" -m pip install --upgrade pip
  [[ -f requirements.txt ]] && "$PY" -m pip install -r requirements.txt
  [[ -f pyproject.toml ]] && "$PY" -m pip install -e . 2>/dev/null || true
fi

if [[ -f go.mod ]]; then command -v go >/dev/null && go mod download; fi
if [[ -f Cargo.toml ]]; then command -v cargo >/dev/null && cargo fetch; fi

echo "Setup complete."
