# Testing

Keep unit tests close to the implementation and add integration tests for cross-component behavior.
