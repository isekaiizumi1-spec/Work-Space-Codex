# Architecture

Document major components, boundaries, data flow, and important design decisions here.
