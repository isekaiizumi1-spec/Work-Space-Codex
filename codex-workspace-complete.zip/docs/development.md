# Development

Use `bash .codex/setup.sh` to prepare the environment and `bash scripts/check.sh` to validate changes.
