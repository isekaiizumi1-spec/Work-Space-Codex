# Documentation

Start with `architecture.md`, `development.md`, and `testing.md`.
